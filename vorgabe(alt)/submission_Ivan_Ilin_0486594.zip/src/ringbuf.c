#include "../include/ringbuf.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>

// Ivan Ilin Matr.-Nur.: 0486594

// initialisiere alles, begin ist der Start, d.h. die Adresse des Buffers, erstmal sind write und read auch am Anfang,
// und das Ende ist die letzte Adresse, d. h. Anfang+size
void ringbuffer_init(rbctx_t *context, void *buffer_location, size_t buffer_size) {
    context->begin = buffer_location;
    context->read = context->begin;
    context->write = context->begin;
    context->end = buffer_location + buffer_size;

    // initialisiere auch alle mutexes und signals (jetzt nur noch 1 von beiden)
    pthread_mutex_init(&context->mtx, NULL);
    pthread_cond_init(&context->sig, NULL);
}

int ringbuffer_write(rbctx_t *context, void *message, size_t message_len) {

    // totale Länge ist die Nachricht selbst und die Größe des Blocks mit der Größe der Nachricht, die ist immer
    // gleich der Größe von size_t
    size_t total_length = sizeof(size_t) + message_len;
    // gleich werden wir schreiben, nur 1 Prozess gleichzeitig kann es machen
    pthread_mutex_lock(&context->mtx);

    size_t space_left;
    struct timespec timelimit;
    int wakey_wakey;

    size_t diff = context->end - context->begin;

    // wenn die Länge der Nachricht ist größer als die Länge des Buffers selbst, können wir damit nichts anfangen
    if (total_length > (diff)) {
        pthread_mutex_unlock(&context->mtx);
        return RINGBUFFER_FULL;
    }

    // es gibt 2 mögliche Fälle, wir gucken, ob der write-Pfeil vor oder nach dem read-Pfeil steht, und überprüfen,
    // ob wir überhaupt genug Platz haben
    do {
        if (context->write >= context->read) {
            // wir berechen, wie Platz uns zur Verfügung steht, stückweise
            // hier haben wir also Platz nach write bis Ende und von Anfang bis write
            size_t space_left_temp = context->end - context->write;
            space_left = space_left_temp + (context->read - context->begin) - 1; // 1 muss man einfach subtrahieren, es muss so
        } else {
            // hier haben wir Platz einfach nach write und bis read
            space_left = context->read - context->write - 1;
        }

        // wenn wir genug Platz fürs Schreiben haben, gehen wir aus der Schleife raus
        if (space_left >= total_length) {
            break;
        }

        // wenn wir nicht genug Platz haben, müssen wir warten, bis der Platz frei wird

        // wir weisen den jetzigen Zeitstempel der Variable timelimit
        clock_gettime(CLOCK_REALTIME, &timelimit);
        timelimit.tv_sec += RBUF_TIMEOUT; // wir addieren RBUF_TIMEOUT dem Zeistempel hinzu
        //timelimit.tv_sec += RBUF_TIMEOUT; // interessanterweise würde alles immernoch funktionieren im Sinne tests sagen alles gut


        // d. h. (wie ich es verstehe, kann nicht komplett richtig sein) das Programm läuft sehr schnell, und ich setze
        // die Begrenzung, wann thread aufgewacht werden muss, diese Begrenzung ist die Zeit des Erstellens des
        // Zeitstempels + 1 Sekunde; wenn dieser neuer Zeitstempel erreicht wird, wird thread aufgewacht

        wakey_wakey = pthread_cond_timedwait(&context->sig, &context->mtx, &timelimit);
        if (wakey_wakey == ETIMEDOUT) {
            pthread_mutex_unlock(&context->mtx);
            return RINGBUFFER_FULL;
        }
    } while (1); // es gibt keine Bedingungen hier, man soll die Schleife einfach laufen lassen, die Logik dadrin
    // kümmert sich um die Terminierung und korrekte Ausführung
    // und die Bedingungen machen Folgendes: wir drehen die Schleife entweder bis wir den Platz bekommen, oder bis uns die
    // Zeit abläuft

    // hier arbeiten wir mit dem Header
    if (context->write + sizeof(size_t) > context->end) {
        //hinzuaddieren nicht können und size_t Größe da rein nicht passt, also das Ende wird überschritten,
        // splitten wir Header auf und fügen so viel wie wir können, was übrig bleibt fügen wir am Anfang des Buffers hinzu
        size_t part_size = context->end - context->write;
        memcpy(context->write, &message_len, part_size);
        memcpy(context->begin, ((uint8_t * ) & message_len) + part_size, sizeof(size_t) - part_size);
        context->write = context->begin + (sizeof(size_t) - part_size);
    } else {
        // wenn wir Header einfach dazu schreiben können, machen wir es
        memcpy(context->write, &message_len, sizeof(size_t));
        context->write += sizeof(size_t);
    }

    // wir machen das Gleiche wie zuvor, diesmal aber mit der Nachricht selbst
    if (context->write + message_len > context->end) {
        size_t part_size = context->end - context->write;
        memcpy(context->write, message, part_size);
        memcpy(context->begin, ((uint8_t *) message) + part_size, message_len - part_size);
        context->write = context->begin + (message_len - part_size);
    } else {
        memcpy(context->write, message, message_len);
        context->write += message_len;
    }

    // wichtig den Pointer rüberzuschicken, wenn der auf Ende zeigt
    if (context->write == context->end) {
        context->write = context->begin;
    }
    // signalisiere, dass jemand anders mit dem Buffer arbeiten darf
    pthread_cond_signal(&context->sig);
    pthread_mutex_unlock(&context->mtx);

    return SUCCESS;
}

int ringbuffer_read(rbctx_t *context, void *buffer, size_t *buffer_len) {
    pthread_mutex_lock(&context->mtx);
    // wenn read gleich write, heißt es, dass der Buffer im Startzustand sich befindet, es gibt nichts zu lesen
    // d. h., dass wir warten müssen, bis wir etwas lesen können
    while (context->read == context->write) {
        struct timespec timelimit;
        clock_gettime(CLOCK_REALTIME, &timelimit);
        timelimit.tv_sec += 1;

        int ret = pthread_cond_timedwait(&context->sig, &context->mtx, &timelimit);
        if (ret == ETIMEDOUT) {
            pthread_mutex_unlock(&context->mtx);
            return RINGBUFFER_EMPTY;
        }
    }

    size_t message_length;
    // wir beginnen mit dem Lesen vom Header
    // ähnliches Schema wie zuvor: um out of bounds nicht zu lesen, wenn es vorkommt, lesen wir teilweise bis Ende des Buffers
    // und was übrig zu lesen ist am Anfang
    // und dabei lesen wir immer sizeof(size_t) lang aus dem Buffer; das, was wir auslesen, ist dann die länge der Nachricht,
    // die wir danach lesen werden
    if (context->read + sizeof(size_t) > context->end) {
        size_t part_size = context->end - context->read;
        memcpy(&message_length, context->read, part_size);
        memcpy(((uint8_t * ) & message_length) + part_size, context->begin, sizeof(size_t) - part_size);
        context->read = context->begin + (sizeof(size_t) - part_size);
    } else {
        memcpy(&message_length, context->read, sizeof(size_t));
        context->read += sizeof(size_t);
    }

    // falls die Nachricht für den Buffer zu groß ist, geben wir einen Fehler aus
    if (*buffer_len < message_length) {
        pthread_mutex_unlock(&context->mtx);
        return OUTPUT_BUFFER_TOO_SMALL;
    }

    // wir machen das am Ende, was die Aufgabenstellung erfordert, nämlich folgendes:
    //An die Speicheradresse, auf die buffer_len zeigt, schreiben wir am Ende des Lesevorgangs, wie lang die
    //gelesene Nachricht tatsächlich war
    *buffer_len = message_length;

    // nun überprüfen wir, ob wir out of bounds beim Lesen der Nachricht aus dem Buffer vom Anfang (read) beginnend betreten
    if (context->read + message_length > context->end) {
        // wenn das der Fall ist, splitten wir auf ähnlich wie früher
        size_t part_size = context->end - context->read;
        memcpy(buffer, context->read, part_size);
        memcpy((uint8_t *) buffer + part_size, context->begin, message_length - part_size);
        context->read = context->begin + (message_length - part_size);
    } else {
        // ansonsten kopieren wir direkt
        memcpy(buffer, context->read, message_length);
        context->read += message_length;
    }

    // nochmal nicht vergessen, den Pointer rüberzuschicken, wenn der auf Ende zeigt
    if (context->read == context->end) {
        context->read = context->begin;
    }

    // nachdem wir gelesen haben, signalisieren wir darüber und unlocken mutex
    pthread_cond_signal(&context->sig);
    pthread_mutex_unlock(&context->mtx);

    return SUCCESS;
}

void ringbuffer_destroy(rbctx_t *context) {
    // hier eliminieren wir alle mutexes und signals (2 Stück)
    pthread_mutex_destroy(&context->mtx);
    pthread_cond_destroy(&context->sig);
}