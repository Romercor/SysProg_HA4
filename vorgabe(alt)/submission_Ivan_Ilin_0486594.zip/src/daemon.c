#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "../include/daemon.h"
#include "../include/ringbuf.h"

// Ivan Ilin Matr.-Nur.: 0486594
// (habe hier nichts verändert)

/* IN THE FOLLOWING IS THE CODE PROVIDED FOR YOU
 * changing the code will result in points deduction */

/********************************************************************
* NETWORK TRAFFIC SIMULATION:
* This section simulates incoming messages from various ports using
* files. Think of these input files as data sent by clients over the
* network to our computer. The data isn't transmitted in a single
* large file but arrives in multiple small packets. This concept
* is discussed in more detail in the advanced module:
* Rechnernetze und Verteilte Systeme
*
* To simulate this parallel packet-based data transmission, we use multiple
* threads. Each thread reads small segments of the files and writes these
* smaller packets into the ring buffer. Between each packet, the
* thread sleeps for a random time between 1 and 100 us. This sleep
* simulates that data packets take varying amounts of time to arrive.
*********************************************************************/
typedef struct {
    rbctx_t* ctx;
    connection_t* connection;
} w_thread_args_t;

void* write_packets(void* arg) {
    /* extract arguments */
    rbctx_t* ctx = ((w_thread_args_t*) arg)->ctx;
    size_t from = (size_t) ((w_thread_args_t*) arg)->connection->from;
    size_t to = (size_t) ((w_thread_args_t*) arg)->connection->to;
    char* filename = ((w_thread_args_t*) arg)->connection->filename;

    /* open file */
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Cannot open file with name %s\n", filename);
        exit(1);
    }

    /* read file in chunks and write to ringbuffer with random delay */
    unsigned char buf[MESSAGE_SIZE];
    size_t packet_id = 0;
    size_t read = 1;
    while (read > 0) {
        size_t msg_size = MESSAGE_SIZE - 3 * sizeof(size_t);
        read = fread(buf + 3 * sizeof(size_t), 1, msg_size, fp);
        if (read > 0) {
            memcpy(buf, &from, sizeof(size_t));
            memcpy(buf + sizeof(size_t), &to, sizeof(size_t));
            memcpy(buf + 2 * sizeof(size_t), &packet_id, sizeof(size_t));
            while(ringbuffer_write(ctx, buf, read + 3 * sizeof(size_t)) != SUCCESS){
                usleep(((rand() % 50) + 25)); // sleep for a random time between 25 and 75 us
            }
        }
        packet_id++;
        usleep(((rand() % (100 -1)) + 1)); // sleep for a random time between 1 and 100 us
    }
    fclose(fp);
    return NULL;
}

/* END OF PROVIDED CODE */


/********************************************************************/

/* YOUR CODE STARTS HERE */

// 1. read functionality
// 2. filtering functionality
// 3. (thread-safe) write to file functionality

typedef struct {
    rbctx_t *ctx;
    size_t *packet_counts;
    pthread_mutex_t *mutex;
    pthread_cond_t *cond;
} r_thread_args_t;

int is_malicious(const char *message, size_t len) {
    const char *keyword = "malicious";
    size_t key_len = strlen(keyword);
    size_t i, j;

    for (i = 0, j = 0; i < len && j < key_len; i++) {
        if (message[i] == keyword[j]) {
            j++;
            if (j == key_len){
                return 1;
            }
        }
    }

    //return j == key_len;
    return 0;
}

/*
void cleanup_handler(void *arg) {
    FILE *fp = (FILE *)arg;
    if (fp != NULL) {
        fclose(fp);
        printf("File closed in cleanup handler\n");
    }
    printf("Cleanup handler executed\n");
}

 */

int contains_malicious(const char *message, size_t message_len) {
    const char *malicious = "malicious";
    size_t m_len = strlen(malicious);

    size_t j = 0;
    for (size_t i = 0; i < message_len; ++i) {
        if (message[i] == malicious[j]) {
            ++j;
            if (j == m_len) {
                return 1;
            }
        }
    }
    return 0;
}

void *read_packets(void *arg) {
    r_thread_args_t *args = (r_thread_args_t *) arg;
    rbctx_t *ctx = args->ctx;
    size_t *packet_counts = args->packet_counts;
    pthread_mutex_t *mutex = args->mutex;
    pthread_cond_t *cond = args->cond;

    uint8_t fin_buf[MESSAGE_SIZE];
    size_t size_of_size = sizeof(size_t);

    printf("Read thread started\n");

    while (1) {
        // Дозволяємо завершення потоку
        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
        pthread_testcancel(); // Перевірка, чи не було запиту на завершення
        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);

        size_t len = MESSAGE_SIZE;
        int temp = ringbuffer_read(ctx, fin_buf, &len);

        if (temp != SUCCESS) {
            usleep(100);
            continue;
        }

        size_t read_from = *(size_t *) fin_buf;
        size_t read_to = *(size_t *) (fin_buf + size_of_size);
        size_t read_packet_id = *(size_t *) (fin_buf + 2 * size_of_size);
        char *actual = (char *) (fin_buf + 3 * size_of_size);
        size_t actual_mes_len = len - 3 * size_of_size;

        // Фільтрація на основі умов
        if (contains_malicious(actual, actual_mes_len)
            || read_to == 42 || read_from == 42 ||
        read_to + read_from == 42 || read_to == read_from) {
            pthread_mutex_lock(&mutex[read_from - 1]);
            packet_counts[read_to]++;
            pthread_cond_broadcast(&cond[read_from - 1]);
            pthread_mutex_unlock(&mutex[read_from - 1]);
            continue;
        } else {
            // Очікування правильного порядку пакетів
            pthread_mutex_lock(&mutex[read_from - 1]);
            while (packet_counts[read_to] != read_packet_id) {
                pthread_cond_wait(&cond[read_from - 1], &mutex[read_from - 1]);
            }
            packet_counts[read_to]++;
            pthread_cond_broadcast(&cond[read_from - 1]);
            pthread_mutex_unlock(&mutex[read_from - 1]);

            // Формування імені файлу та запис у файл
            char filename[20];
            snprintf(filename, sizeof(filename), "%zu.txt", read_to);

            FILE *file = fopen(filename, "a");
            if (file != NULL) {
                fwrite(actual, 1, actual_mes_len, file);
                fclose(file);
            }
        }
    }

    return NULL;
}

/* YOUR CODE ENDS HERE */

/********************************************************************/


int simpledaemon(connection_t* connections, int nr_of_connections) {
    // Initialize ringbuffer
    rbctx_t rb_ctx;
    size_t rbuf_size = 1024;
    void *rbuf = malloc(rbuf_size);
    if (rbuf == NULL) {
        fprintf(stderr, "Error allocating ringbuffer\n");
        return 1;
    }
    ringbuffer_init(&rb_ctx, rbuf, rbuf_size);

    // Initialize mutexes and condition variables
    pthread_mutex_t mutex[MAXIMUM_PORT];
    pthread_cond_t cond[MAXIMUM_PORT];
    for (int i = 0; i < MAXIMUM_PORT; i++) {
        pthread_mutex_init(&mutex[i], NULL);
        pthread_cond_init(&cond[i], NULL);
    }

    // Initialize packet_counts array
    size_t packet_counts[MAXIMUM_PORT] = {0};

    // Prepare writer threads
    w_thread_args_t w_thread_args[nr_of_connections];
    pthread_t w_threads[nr_of_connections];
    for (int i = 0; i < nr_of_connections; i++) {
        w_thread_args[i].ctx = &rb_ctx;
        w_thread_args[i].connection = &connections[i];
        if (connections[i].from > MAXIMUM_PORT || connections[i].to > MAXIMUM_PORT ||
        connections[i].from < MINIMUM_PORT || connections[i].to < MINIMUM_PORT) {
            fprintf(stderr, "Port numbers %d and/or %d are out of range\n", connections[i].from, connections[i].to);
            exit(1);
        }
        pthread_create(&w_threads[i], NULL, write_packets, &w_thread_args[i]);
    }

    // Prepare reader threads
    pthread_t r_threads[NUMBER_OF_PROCESSING_THREADS];
    r_thread_args_t r_thread_args;
    r_thread_args.ctx = &rb_ctx;
    r_thread_args.packet_counts = packet_counts;
    r_thread_args.mutex = mutex;
    r_thread_args.cond = cond;
    for (int i = 0; i < NUMBER_OF_PROCESSING_THREADS; i++) {
        pthread_create(&r_threads[i], NULL, read_packets, &r_thread_args);
    }

    // Wait for 5 seconds before canceling reading threads
    printf("daemon: waiting for 5 seconds before canceling reading threads\n");
    sleep(5);

    // Cancel reading threads and wait for all threads to finish
    for (int i = 0; i < NUMBER_OF_PROCESSING_THREADS; i++) {
        pthread_cancel(r_threads[i]);
    }
    for (int i = 0; i < nr_of_connections; i++) {
        pthread_join(w_threads[i], NULL);
    }
    for (int i = 0; i < NUMBER_OF_PROCESSING_THREADS; i++) {
        pthread_join(r_threads[i], NULL);
    }

    // Cleanup: Destroy mutexes and condition variables
    for (int i = 0; i < MAXIMUM_PORT; i++) {
        pthread_mutex_destroy(&mutex[i]);
        pthread_cond_destroy(&cond[i]);
    }
    free(rbuf);
    ringbuffer_destroy(&rb_ctx);

    return 0;
}